<!--TRADEMARK BAHAGIAN FOOTER-->
<center>
<footer>
<style>
	footer{
		position: static;
		background-color: steelblue;
		width: 100%;
	}
</style>
	<center>
		<font style='font-size:13px' color='white'> Copyright & Copy; 2021<BR>
		&#169;<?php echo $footer;?>
		</font>
	</center>
</footer>
</center>