<!--PAPARAN HEADER UNTUK SETIAP HALAMAN -->
<?php require 'sambung.php'; ?>
<html>
<head>
<title> <?php echo $nama_sistem; ?>-Sains Komputer</title>
</head>
<body><center>
<TABLE WIDTH="90%" BORDER="0" cellpadding="0"
CELLSPACING="0">
<TR>
<img src="header.jpg" width="90%" height="150px"
align="center" style= "background-repeat:no-repeat;">
</P>
</TR>
</TABLE>
</body> </center>
</html>